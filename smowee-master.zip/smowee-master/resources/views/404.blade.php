@extends ('layout.master')

@section('content')

<section class="pnf">
  <div class="pnf-grid">
    <img src="/img/logo-smowee-footer.png" />
    <h2>404</h2>
    <h3>Página não encontrada</h3>
    <a>◀ Voltar para home</a>
  </div>
</section>

@endsection
