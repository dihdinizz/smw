<html>
    <head></head>
    <body class="color: #000">
        <h3>{{ $title }}</h3>
        <hr>
        <p>
            Nome: {{ $name }};<br>
            Email: {{ $email }};<br>
            Telefone: {{ $telephone }};<br>
            Nascimento: {{ $birth_day }};<br>
            CPF: {{ $cpf }};<br>
            Cidade: {{ $cpf }};<br>
        </p>
    </body>
</html>