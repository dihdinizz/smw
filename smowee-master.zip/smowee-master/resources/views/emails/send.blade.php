<html>
    <head></head>
    <body class="color: #000">
        <h3>{{ $title }}</h3>
        <hr>
        <p>
            Nome: {{ $name }};<br>
            Email: {{ $email }};<br>
            Telefone: {{ $tel }};<br>
        </p>
        <p>{{ $content }}</p>
    </body>
</html>