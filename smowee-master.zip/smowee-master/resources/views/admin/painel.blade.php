@extends ('admin.master')

@section ('content')
  <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
          <h1 class="page-header">Bem-vindo ao Painel Administrativo da smowee</h1>  
          <p class="lead">Gerencie o conteúdo disponível por aqui. Divirta-se.</p>
          
      </div>
  </div>
@endsection