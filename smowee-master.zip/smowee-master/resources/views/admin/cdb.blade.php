@extends ('admin.master')

@section ('content')
  <h4>Inserir um novo produto</h4>
@endsection